import React from 'react';
import {
  BottomTabNavigationEventMap,
  BottomTabBarProps,
} from '@react-navigation/bottom-tabs';
import {NavigationHelpers, ParamListBase} from '@react-navigation/native';
import {TouchableOpacity, Text, View, StyleSheet} from 'react-native';

type TabProps = {
  name: string;
  label: string;
  navigation: NavigationHelpers<ParamListBase, BottomTabNavigationEventMap>;
};

function Tab({label, name, navigation}: TabProps) {
  return (
    <TouchableOpacity onPress={() => navigation.navigate(name)}>
      <Text>{label}</Text>
    </TouchableOpacity>
  );
}

export function BottomTabBar({state, navigation}: BottomTabBarProps) {
  const middleIndex = Math.ceil(state.routes.length / 2);
  const leftRoutes = state.routes.slice(0, middleIndex);
  const rightRoutes = state.routes.slice(middleIndex, state.routes.length);

  return (
    <View style={styles.container}>
      {leftRoutes.map(({name, key}) => (
        <Tab key={key} label={name} name={name} navigation={navigation} />
      ))}

      <Tab label="Global Modal" name="globalModal" navigation={navigation} />

      {rightRoutes.map(({name, key}) => (
        <Tab key={key} label={name} name={name} navigation={navigation} />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    backgroundColor: 'white',
    paddingHorizontal: 24,
    paddingVertical: 16,
    alignItems: 'center',
    justifyContent: 'space-between',
  },
});
