import {useNavigation} from '@react-navigation/native';
import React from 'react';
import {View, Text, StyleSheet, Button} from 'react-native';

export function ProductListPage() {
  const navigation = useNavigation();

  return (
    <View style={styles.container}>
      <Text>ProductList</Text>
      <Button
        title="Product #1"
        onPress={() => navigation.navigate('productDetails')}
      />
      <Button
        title="Product #2"
        onPress={() => navigation.navigate('productDetails')}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
  },
});
