import React from 'react';
import {View, Text, StyleSheet, Button} from 'react-native';
import {useAuthStore} from '../store/useAuthStore';
import {useNavigation} from '@react-navigation/native';

export function HomePage() {
  const signUp = useAuthStore(store => store.signUp);
  const navigation = useNavigation();

  return (
    <View style={styles.container}>
      <Text>Home</Text>
      <Button title="SignUp" onPress={signUp} />

      <Button
        title="Go To Profile"
        onPress={() => navigation.navigate('profile' as never)}
      />

      <Button
        title="Go To Cart"
        onPress={() => navigation.navigate('cart' as never)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f0f0f0',
  },
});
