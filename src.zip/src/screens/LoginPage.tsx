import React from 'react';
import {View, Text, StyleSheet, Button} from 'react-native';
import {useAuthStore} from '../store/useAuthStore';

export function LoginPage() {
  const signIn = useAuthStore(store => store.signIn);

  return (
    <View style={styles.container}>
      <Text>Login</Text>

      <Button title="Login" onPress={signIn} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
  },
});
