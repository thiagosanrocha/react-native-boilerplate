import React from 'react';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {CartPage} from '../screens/CartPage';
import {HomePage} from '../screens/HomePage';
import {BottomTabBar} from '../components/BottomTabBar';
import {ProductsRoutes} from './ProductsRoutes';

const BottomTab = createBottomTabNavigator();

export function MainRoutes() {
  return (
    <BottomTab.Navigator tabBar={BottomTabBar}>
      <BottomTab.Screen name="home" component={HomePage} />
      <BottomTab.Screen
        name="products"
        component={ProductsRoutes}
        options={{headerShown: false}}
      />
      <BottomTab.Screen name="cart" component={CartPage} />
    </BottomTab.Navigator>
  );
}
