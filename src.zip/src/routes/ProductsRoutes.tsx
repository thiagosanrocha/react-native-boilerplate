import React from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {ProductDetailsPage} from '../screens/ProductDetails';
import {ProductListPage} from '../screens/ProductList';

const ProductsStack = createNativeStackNavigator();

export function ProductsRoutes() {
  return (
    <ProductsStack.Navigator initialRouteName="main">
      <ProductsStack.Screen name="productList" component={ProductListPage} />
      <ProductsStack.Screen
        name="productDetails"
        component={ProductDetailsPage}
      />
    </ProductsStack.Navigator>
  );
}
