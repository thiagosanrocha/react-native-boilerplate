import React from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {LoginPage} from '../screens/LoginPage';
import {SignUpPage} from '../screens/SignUpPage';

const AuthStack = createNativeStackNavigator();

export function AuthRoutes() {
  return (
    <AuthStack.Navigator>
      <AuthStack.Screen name="login" component={LoginPage} />
      <AuthStack.Screen name="signUp" component={SignUpPage} />
    </AuthStack.Navigator>
  );
}
