import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {GlobalModal} from '../screens/GlobalModal';
import {MainRoutes} from './MainRoutes';
import {AuthRoutes} from './AuthRoutes';
import {useAuthStore} from '../store/useAuthStore';

const AppStack = createNativeStackNavigator();

export function AppRoutes() {
  const isLogged = useAuthStore(store => store.isLogged);

  return (
    <NavigationContainer>
      <AppStack.Navigator>
        {!isLogged ? (
          <AppStack.Screen
            name="auth"
            component={AuthRoutes}
            options={{
              headerShown: false,
            }}
          />
        ) : (
          <AppStack.Screen
            name="main"
            component={MainRoutes}
            options={{
              headerShown: false,
            }}
          />
        )}

        <AppStack.Screen
          name="globalModal"
          component={GlobalModal}
          options={{presentation: 'modal'}}
        />
      </AppStack.Navigator>
    </NavigationContainer>
  );
}
