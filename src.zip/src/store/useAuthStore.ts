import {create} from 'zustand';

type Auth = {
  isLogged: boolean;
  signIn(): void;
  signUp(): void;
};

export const useAuthStore = create<Auth>(set => ({
  isLogged: false,
  signIn: () => {
    set(store => ({...store, isLogged: true}));
  },
  signUp: () => {
    set(store => ({...store, isLogged: false}));
  },
}));
